// a simple TeX-input example
var mjAPI = require("mathjax-node");
mjAPI.config({
  MathJax: {
    // traditional MathJax configuration
  }
});
mjAPI.start();

var yourMath = 's = \\sum_{i=1}^{100}';

mjAPI.typeset({
  math: yourMath,
  format: "TeX",
  css: true,
  mml: true
}, function(data) {
  console.log(data.css);
  console.log(data.mml);
});
