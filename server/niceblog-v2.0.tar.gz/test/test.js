function getSummary(html, maxLength) {
  const TAG_REG = /<.*?>/;
  maxLength = maxLength || 200;
  let summary = '';
  while (html && summary.length < maxLength) {
    let cap = TAG_REG.exec(html);
    let end = maxLength - summary.length > cap.index ? cap.index : maxLength - summary.length;
    summary += html.substring(0, end);
    html = html.substring(cap.index + cap[0].length);
  }
  return summary;
}

function clearTag(html) {
  const TAG_REG = /<.*?>/g;
  return html.replace(TAG_REG, '');
}


console.log(clearTag(`<p >马上就要毕业了。突然想起来，大概在去年的这个时候，写了两篇关于爬虫的博客。今天打开一看才发现浏览量加起来快到3000，虽然不算多，但真的不胜惶恐。</p><p >从技术上看，这两篇博客写的</p>`));
